

CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_created_at_index` (`created_at`),
  KEY `activities_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `blind_bag_compositions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `price_series_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '价格系列编码',
  `probability` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '出现概率(%)',
  `min_quantity` int(11) NOT NULL DEFAULT '1' COMMENT '最小数量',
  `max_quantity` int(11) NOT NULL DEFAULT '1' COMMENT '最大数量',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '说明',
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_series` (`product_id`,`price_series_code`),
  KEY `blind_bag_compositions_product_id_index` (`product_id`),
  KEY `blind_bag_compositions_price_series_code_index` (`price_series_code`),
  KEY `blind_bag_compositions_is_active_index` (`is_active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `blind_bag_deliveries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `blind_bag_product_id` bigint(20) unsigned NOT NULL,
  `delivery_product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blind_bag_deliveries_blind_bag_product_id_foreign` (`blind_bag_product_id`),
  KEY `blind_bag_deliveries_delivery_product_id_foreign` (`delivery_product_id`),
  KEY `blind_bag_deliveries_sale_id_blind_bag_product_id_index` (`sale_id`,`blind_bag_product_id`),
  KEY `blind_bag_deliveries_sale_id_index` (`sale_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `blind_bag_deliveries` VALUES
('1', '2', '1', '2', '200', '4.00', '800.00', NULL, '2025-07-10 17:28:47', '2025-07-10 17:28:47'),
('2', '2', '1', '3', '20', '15.00', '300.00', NULL, '2025-07-10 17:28:47', '2025-07-10 17:28:47'),
('3', '2', '1', '4', '100', '25.00', '2500.00', NULL, '2025-07-10 17:28:47', '2025-07-10 17:28:47'),
('4', '2', '9', '2', '100', '4.00', '400.00', NULL, '2025-07-10 17:28:47', '2025-07-10 17:28:47'),
('5', '2', '9', '3', '10', '15.00', '150.00', NULL, '2025-07-10 17:28:47', '2025-07-10 17:28:47'),
('6', '2', '9', '4', '50', '25.00', '1250.00', NULL, '2025-07-10 17:28:47', '2025-07-10 17:28:47'),
('7', '3', '1', '2', '200', '4.00', '800.00', NULL, '2025-07-10 17:34:14', '2025-07-10 17:34:14'),
('8', '3', '1', '3', '50', '15.00', '750.00', NULL, '2025-07-10 17:34:14', '2025-07-10 17:34:14'),
('9', '3', '1', '4', '200', '25.00', '5000.00', NULL, '2025-07-10 17:34:14', '2025-07-10 17:34:14'),
('10', '3', '9', '2', '200', '4.00', '800.00', NULL, '2025-07-10 17:34:14', '2025-07-10 17:34:14'),
('11', '3', '9', '3', '50', '15.00', '750.00', NULL, '2025-07-10 17:34:14', '2025-07-10 17:34:14'),
('12', '3', '9', '4', '200', '25.00', '5000.00', NULL, '2025-07-10 17:34:14', '2025-07-10 17:34:14'),
('13', '4', '1', '2', '100', '4.00', '400.00', NULL, '2025-07-10 17:38:25', '2025-07-10 17:38:25'),
('14', '4', '1', '3', '100', '15.00', '1500.00', NULL, '2025-07-10 17:38:25', '2025-07-10 17:38:25'),
('15', '4', '1', '4', '150', '25.00', '3750.00', NULL, '2025-07-10 17:38:25', '2025-07-10 17:38:25'),
('16', '4', '9', '2', '100', '4.00', '400.00', NULL, '2025-07-10 17:38:25', '2025-07-10 17:38:25'),
('17', '4', '9', '3', '100', '15.00', '1500.00', NULL, '2025-07-10 17:38:25', '2025-07-10 17:38:25'),
('18', '4', '9', '4', '150', '25.00', '3750.00', NULL, '2025-07-10 17:38:25', '2025-07-10 17:38:25'),
('19', '7', '1', '2', '200', '4.00', '800.00', NULL, '2025-07-10 17:57:55', '2025-07-10 17:57:55'),
('20', '7', '1', '3', '100', '15.00', '1500.00', NULL, '2025-07-10 17:57:55', '2025-07-10 17:57:55'),
('21', '7', '1', '4', '100', '25.00', '2500.00', NULL, '2025-07-10 17:57:55', '2025-07-10 17:57:55'),
('22', '7', '9', '2', '100', '4.00', '400.00', NULL, '2025-07-10 17:57:55', '2025-07-10 17:57:55'),
('23', '7', '9', '3', '50', '15.00', '750.00', NULL, '2025-07-10 17:57:55', '2025-07-10 17:57:55'),
('24', '7', '9', '4', '50', '25.00', '1250.00', NULL, '2025-07-10 17:57:55', '2025-07-10 17:57:55'),
('25', '8', '1', '2', '40', '4.00', '160.00', NULL, '2025-07-10 18:03:58', '2025-07-10 18:03:58'),
('26', '8', '1', '3', '5', '15.00', '75.00', NULL, '2025-07-10 18:03:58', '2025-07-10 18:03:58'),
('27', '8', '1', '4', '20', '25.00', '500.00', NULL, '2025-07-10 18:03:58', '2025-07-10 18:03:58'),
('28', '11', '1', '2', '21', '4.00', '84.00', NULL, '2025-07-10 18:11:04', '2025-07-10 18:11:04'),
('29', '11', '1', '3', '2', '15.00', '30.00', NULL, '2025-07-10 18:11:04', '2025-07-10 18:11:04'),
('30', '11', '1', '4', '15', '25.00', '375.00', NULL, '2025-07-10 18:11:04', '2025-07-10 18:11:04'),
('31', '12', '1', '2', '20', '4.00', '80.00', NULL, '2025-07-11 06:02:05', '2025-07-11 06:02:05'),
('32', '12', '1', '3', '5', '15.00', '75.00', NULL, '2025-07-11 06:02:05', '2025-07-11 06:02:05'),
('33', '12', '1', '4', '10', '25.00', '250.00', NULL, '2025-07-11 06:02:05', '2025-07-11 06:02:05'),
('34', '13', '1', '2', '10', '4.00', '40.00', NULL, '2025-07-11 12:13:33', '2025-07-11 12:13:33'),
('35', '13', '1', '3', '10', '15.00', '150.00', NULL, '2025-07-11 12:13:33', '2025-07-11 12:13:33'),
('36', '13', '1', '4', '10', '25.00', '250.00', NULL, '2025-07-11 12:13:33', '2025-07-11 12:13:33');


CREATE TABLE `blind_bag_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blind_bag_sale_id` bigint(20) unsigned NOT NULL,
  `price_series_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '实际发货的价格系列编码',
  `quantity` int(11) NOT NULL COMMENT '数量',
  `unit_cost` decimal(10,2) NOT NULL COMMENT '单位成本',
  `total_cost` decimal(12,2) NOT NULL COMMENT '总成本',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blind_bag_details_blind_bag_sale_id_index` (`blind_bag_sale_id`),
  KEY `blind_bag_details_price_series_code_index` (`price_series_code`),
  KEY `blind_bag_details_blind_bag_sale_id_price_series_code_index` (`blind_bag_sale_id`,`price_series_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `blind_bag_sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL COMMENT '盲袋数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '盲袋单价',
  `total_amount` decimal(12,2) NOT NULL COMMENT '总金额',
  `total_cost` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '实际总成本',
  `profit` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '利润',
  `profit_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '利润率',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blind_bag_sales_sale_id_index` (`sale_id`),
  KEY `blind_bag_sales_product_id_index` (`product_id`),
  KEY `blind_bag_sales_sale_id_product_id_index` (`sale_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  UNIQUE KEY `categories_code_unique` (`code`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_is_active_index` (`is_active`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` VALUES
('2', '手机链', '', NULL, NULL, NULL, '0', '1', '2025-07-10 07:16:27', '2025-07-10 07:16:27');


CREATE TABLE `inventories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventories_store_id_foreign` (`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `inventory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `store_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `min_quantity` int(11) NOT NULL DEFAULT '50',
  `max_quantity` int(11) NOT NULL DEFAULT '1000',
  `last_check_date` datetime DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_store_id_foreign` (`store_id`),
  KEY `inventory_product_store_index` (`product_id`,`store_id`),
  KEY `inventory_quantity_index` (`quantity`),
  KEY `inventory_quantity_min_index` (`quantity`,`min_quantity`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory` VALUES
('1', '2', '1', '2525', '50', '1000', '2025-07-10 17:15:20', NULL, '2025-07-09 15:38:35', '2025-07-11 12:13:33'),
('2', '3', '1', '1088', '50', '1000', '2025-07-09 00:00:00', NULL, '2025-07-09 15:38:35', '2025-07-11 12:13:33'),
('3', '6', '1', '0', '50', '1000', NULL, NULL, '2025-07-09 17:38:00', '2025-07-09 17:39:34'),
('4', '5', '1', '50', '50', '1000', '2025-07-10 17:07:19', NULL, '2025-07-09 18:14:35', '2025-07-10 17:07:19'),
('5', '4', '1', '465', '50', '1000', NULL, NULL, '2025-07-10 17:01:31', '2025-07-11 12:13:33');


CREATE TABLE `inventory_check_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_check_record_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `system_quantity` int(11) NOT NULL,
  `actual_quantity` int(11) NOT NULL,
  `difference` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_check_details_inventory_check_record_id_foreign` (`inventory_check_record_id`),
  KEY `inventory_check_details_product_id_foreign` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_check_details` VALUES
('1', '1', '2', '110', '110', '0', '5.00', '0.00', '2025-07-09 18:30:26', '2025-07-09 18:30:26'),
('2', '2', '2', '110', '100', '-10', '5.00', '-50.00', '2025-07-09 18:31:03', '2025-07-09 18:31:03'),
('3', '3', '2', '100', '100', '0', '5.00', '0.00', '2025-07-09 18:32:00', '2025-07-09 18:32:00'),
('4', '3', '3', '150', '100', '-50', '0.00', '0.00', '2025-07-09 18:32:00', '2025-07-09 18:32:00'),
('5', '3', '5', '1000', '1000', '0', '50.00', '0.00', '2025-07-09 18:32:00', '2025-07-09 18:32:00'),
('6', '4', '2', '100', '150', '50', '5.00', '250.00', '2025-07-09 18:32:10', '2025-07-09 18:32:10'),
('7', '4', '3', '100', '100', '0', '0.00', '0.00', '2025-07-09 18:32:10', '2025-07-09 18:32:10'),
('8', '4', '5', '1000', '1000', '0', '50.00', '0.00', '2025-07-09 18:32:10', '2025-07-09 18:32:10'),
('9', '5', '2', '150', '150', '0', '5.00', '0.00', '2025-07-09 18:32:17', '2025-07-09 18:32:17'),
('10', '5', '3', '100', '100', '0', '0.00', '0.00', '2025-07-09 18:32:17', '2025-07-09 18:32:17'),
('11', '5', '5', '1000', '500', '-500', '50.00', '-25000.00', '2025-07-09 18:32:17', '2025-07-09 18:32:17'),
('12', '6', '2', '2150', '2500', '350', '4.00', '1400.00', '2025-07-10 17:15:20', '2025-07-10 17:15:20');


CREATE TABLE `inventory_check_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT '状态：pending=待确认，confirmed=已确认',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_check_records_store_id_foreign` (`store_id`),
  KEY `inventory_check_records_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_check_records` VALUES
('1', '1', '1', 'pending', '库存盘点调整 - 2025-07-09', '2025-07-09 18:30:26', '2025-07-09 18:30:26'),
('2', '1', '1', 'pending', '库存盘点调整 - 2025-07-09', '2025-07-09 18:31:03', '2025-07-09 18:31:03'),
('3', '1', '1', 'pending', '库存盘点调整 - 2025-07-09', '2025-07-09 18:32:00', '2025-07-09 18:32:00'),
('4', '1', '1', 'pending', '库存盘点调整 - 2025-07-09', '2025-07-09 18:32:10', '2025-07-09 18:32:10'),
('5', '1', '1', 'pending', '库存盘点调整 - 2025-07-09', '2025-07-09 18:32:17', '2025-07-09 18:32:17'),
('6', '1', '1', 'pending', '单条库存盘点', '2025-07-10 17:15:20', '2025-07-10 17:15:20');


CREATE TABLE `inventory_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL COMMENT '数量变化，正数为增加，负数为减少',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `type` enum('in','out','adjust','check') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '记录类型：入库、出库、调整、盘点',
  `reference_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关联类型',
  `reference_id` bigint(20) unsigned DEFAULT NULL COMMENT '关联ID',
  `note` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_records_inventory_id_type_index` (`inventory_id`,`type`),
  KEY `inventory_records_reference_type_reference_id_index` (`reference_type`,`reference_id`),
  KEY `inventory_records_inventory_created_index` (`inventory_id`,`created_at`),
  KEY `inventory_records_inventory_id_index` (`inventory_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_records` VALUES
('1', '1', '10', '5.00', '50.00', 'check', 'inventory', '1', '库存盘点调整', '2025-07-09 18:28:51', '2025-07-09 18:28:51'),
('2', '1', '-10', '5.00', '-50.00', 'check', 'inventory', '1', '库存盘点调整', '2025-07-09 18:31:03', '2025-07-09 18:31:03'),
('3', '2', '-50', '0.00', '0.00', 'check', 'inventory', '2', '库存盘点调整', '2025-07-09 18:32:00', '2025-07-09 18:32:00'),
('4', '1', '50', '5.00', '250.00', 'check', 'inventory', '1', '库存盘点调整', '2025-07-09 18:32:10', '2025-07-09 18:32:10'),
('5', '4', '-500', '50.00', '-25000.00', 'check', 'inventory', '4', '库存盘点调整', '2025-07-09 18:32:17', '2025-07-09 18:32:17'),
('6', '1', '350', '4.00', '1400.00', 'check', 'inventory', '1', '库存盘点调整', '2025-07-10 17:15:20', '2025-07-10 17:15:20'),
('7', '1', '100', '0.00', '0.00', 'adjust', NULL, NULL, NULL, '2025-07-10 17:15:30', '2025-07-10 17:15:30');


CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES
('1', '2014_10_12_100000_create_password_reset_tokens_table', '1'),
('2', '2019_12_14_000001_create_personal_access_tokens_table', '1'),
('3', '2024_03_10_000001_create_roles_table', '1'),
('4', '2024_03_10_000002_create_permissions_table', '1'),
('5', '2024_03_10_000002_create_users_table', '1'),
('6', '2024_03_10_000003_create_stores_table', '1'),
('7', '2024_03_10_000004_create_products_table', '1'),
('8', '2024_03_10_000005_create_price_series_table', '1'),
('9', '2024_03_10_000006_create_inventory_tables', '1'),
('10', '2024_03_10_000007_create_system_configs_table', '1'),
('11', '2024_03_10_000008_create_default_admin', '1'),
('12', '2025_06_24_080617_create_inventory_table', '1'),
('13', '2025_06_24_081846_create_inventory_records_table', '1'),
('14', '2025_06_24_082149_add_series_code_to_inventory_check_details_table', '1'),
('15', '2025_06_24_090006_add_deleted_at_to_stores_table', '1'),
('16', '2025_06_24_092210_create_return_records_table', '1'),
('17', '2025_06_24_092217_create_return_details_table', '1'),
('18', '2025_06_24_092856_create_sales_table', '1'),
('19', '2025_06_24_092944_create_price_series_sale_details_table', '1'),
('20', '2025_06_24_093130_add_store_id_to_sales_table', '1'),
('21', '2025_06_24_093743_create_sale_details_table', '1'),
('22', '2025_06_24_133232_add_missing_fields_to_products_table', '1'),
('23', '2025_06_24_133509_add_created_at_to_products_table', '1'),
('24', '2025_06_24_152749_add_supplier_to_stock_in_records_table', '1'),
('25', '2025_06_24_154925_enhance_products_table', '1'),
('26', '2025_06_24_154936_create_product_variants_table', '1'),
('27', '2025_06_24_154942_create_blind_bag_compositions_table', '1'),
('28', '2025_06_24_155001_create_unified_inventories_table', '1'),
('29', '2025_06_24_155010_create_blind_bag_sales_table', '1'),
('30', '2025_06_24_155019_create_blind_bag_details_table', '1'),
('31', '2025_06_24_155433_enhance_sales_table', '1'),
('32', '2025_06_24_155527_enhance_sale_details_table', '1'),
('33', '2025_06_24_160551_fix_unified_inventories_available_quantity', '1'),
('34', '2025_06_24_161318_update_product_type_from_basic_to_standard', '1'),
('36', '2025_07_09_154324_refactor_unified_product_system', '2'),
('37', '2025_07_09_162917_update_inventory_table_to_use_product_id', '2'),
('38', '2025_07_09_165147_update_products_table_add_missing_fields', '3'),
('39', '2025_07_09_171344_add_series_code_to_stock_in_details_table', '4'),
('40', '2025_07_09_171456_update_inventory_table_structure', '5'),
('41', '2025_07_09_171825_update_tables_to_use_product_id', '6'),
('42', '2025_07_09_173142_add_unit_price_and_total_amount_to_stock_in_details_table', '7'),
('43', '2025_01_09_000000_create_activities_table', '8'),
('44', '2025_07_10_062337_add_missing_fields_to_categories_table', '9'),
('45', '2025_07_10_070831_fix_categories_code_field', '10'),
('46', '2025_07_10_080000_create_store_products_table', '11'),
('47', '2025_07_11_085652_update_return_details_to_use_products', '12'),
('48', '2025_07_12_051201_add_order_no_to_sales_table', '13'),
('49', '2025_07_12_081846_add_performance_indexes', '14'),
('50', '2025_01_12_000001_add_performance_indexes', '15'),
('51', '2025_01_13_000001_create_store_transfers_table', '16');


CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_code_unique` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` VALUES
('1', '用户管理', 'user_manage', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('2', '角色管理', 'role_manage', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('3', '权限管理', 'permission_manage', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('4', '入库管理', 'stock_in_manage', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('5', '退货管理', 'return_manage', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('6', '库存查询', 'inventory_query', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('7', '库存统计', 'inventory_statistics', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('8', '销售管理', 'sale_manage', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('9', '销售统计', 'sale_statistics', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('10', '系统配置', 'system_config', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('11', '价格配置', 'price_config', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('12', '数据备份', 'data_backup', NULL, '2025-07-08 15:22:34', '2025-07-08 15:22:34');


CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `price_series` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `price_series_code_unique` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `price_series` VALUES
('1', '29系列', '29', '29.00', '29元价格系列', '1', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('2', '59系列', '59', '59.00', '59元价格系列', '1', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('3', '89系列', '89', '89.00', '89元价格系列', '1', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('4', '159系列', '159', '159.00', '159元价格系列', '1', '2025-07-08 15:22:34', '2025-07-08 15:22:34');


CREATE TABLE `price_series_costs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `price_series_id` bigint(20) unsigned NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `effective_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `price_series_costs_price_series_id_foreign` (`price_series_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `price_series_costs` VALUES
('1', '1', '15.00', '2025-07-08', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('2', '2', '30.00', '2025-07-08', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('3', '3', '45.00', '2025-07-08', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('4', '4', '80.00', '2025-07-08', '2025-07-08 15:22:34', '2025-07-08 15:22:34');


CREATE TABLE `price_series_sale_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `series_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `price_series_sale_details_sale_id_foreign` (`sale_id`),
  KEY `price_series_sale_details_series_code_foreign` (`series_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `product_variants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKU编码',
  `variant_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '变体名称(如:红色、蓝色、L码)',
  `price` decimal(10,2) NOT NULL COMMENT '售价',
  `cost_price` decimal(10,2) NOT NULL COMMENT '成本价',
  `stock` int(11) NOT NULL DEFAULT '0' COMMENT '库存数量',
  `alert_stock` int(11) NOT NULL DEFAULT '10' COMMENT '警戒库存',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否默认变体',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT '状态',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '变体图片',
  `attributes` json DEFAULT NULL COMMENT '变体属性(颜色、尺寸等)',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_variants_sku_unique` (`sku`),
  KEY `product_variants_product_id_index` (`product_id`),
  KEY `product_variants_status_index` (`status`),
  KEY `product_variants_product_id_status_index` (`product_id`,`status`),
  KEY `product_variants_product_id_is_default_index` (`product_id`,`is_default`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_variants` VALUES
('1', '8', 'SP001', '默认', '35.00', '20.00', '80', '15', '1', 'active', NULL, NULL, '0', '2025-07-09 16:53:54', '2025-07-09 16:53:54'),
('2', '10', 'BH001', '默认', '29.00', '15.00', '100', '20', '1', 'active', NULL, NULL, '0', '2025-07-11 09:07:20', '2025-07-11 09:07:20'),
('3', '11', 'BH002', '默认', '59.00', '30.00', '80', '15', '1', 'active', NULL, NULL, '0', '2025-07-11 09:07:20', '2025-07-11 09:07:20'),
('4', '12', 'BH003', '默认', '89.00', '45.00', '60', '10', '1', 'active', NULL, NULL, '0', '2025-07-11 09:07:20', '2025-07-11 09:07:20'),
('5', '13', 'BH004', '默认', '159.00', '80.00', '40', '5', '1', 'active', NULL, NULL, '0', '2025-07-11 09:07:20', '2025-07-11 09:07:20');


CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('standard','blind_bag') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'standard',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cost_price` decimal(10,2) DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT '0',
  `alert_stock` int(11) NOT NULL DEFAULT '0',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_code_unique` (`code`),
  KEY `products_type_is_active_index` (`is_active`),
  KEY `products_type_index` (`type`),
  KEY `products_is_active_index` (`is_active`),
  KEY `products_name_index` (`name`),
  KEY `products_active_type_index` (`is_active`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` VALUES
('1', '盲袋39', 'SP0001', 'blind_bag', '39.00', '0.00', '手机链', '10', '10', 'products/cUqC0qSHDhqCRQ004EtnSXZLIkfA5CiJ6TIZRbds.jpg', NULL, '1', '0', '2025-07-08 15:25:45', '2025-07-10 07:22:06'),
('2', '29系列商品', 'P29', 'standard', '29.00', '4.00', '手机链', '0', '10', 'products/EGQgZ5YsjzR26YrpC8KIP97R1bgJjo1JhjvuyeI2.jpg', '29元价格系列', '1', '0', '2025-07-08 15:22:34', '2025-07-10 16:49:03'),
('3', '59系列商品', 'P59', 'standard', '59.00', '15.00', '手机链', '0', '10', 'products/pRzk4xDGQ6QqMnVMfChTffy4idjAmxa5q8880aw5.jpg', '59元价格系列', '1', '0', '2025-07-08 15:22:34', '2025-07-10 16:48:41'),
('4', '89系列商品', 'P89', 'standard', '89.00', '25.00', '手机链', '0', '10', 'products/kIkLxyXkvqutvEVLk5HbxVHWAOt84HyH4c5UcvJ4.jpg', '89元价格系列', '1', '0', '2025-07-08 15:22:34', '2025-07-10 16:49:27'),
('5', '159系列商品', 'P159', 'standard', '159.00', '70.00', '手机链', '0', '10', 'products/kKMtMxpVNedWyXPWElC7T73uph1Q7foaUbykTVnH.jpg', '159元价格系列', '1', '0', '2025-07-08 15:22:34', '2025-07-10 16:49:50'),
('9', '79盲袋', 'SP0002', 'blind_bag', '79.00', '0.00', '手机链', '0', '10', 'products/as8rgygLey1M4AcogJwe7YhjnTBjGvBLQYs5Nxr5.jpg', NULL, '1', '0', '2025-07-10 16:50:41', '2025-07-10 16:50:41');


CREATE TABLE `return_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `return_record_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(8,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_details_return_record_id_foreign` (`return_record_id`),
  KEY `return_details_product_id_foreign` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `return_details` VALUES
('4', '4', '2', '5', '29.00', '145.00', '20.00', '2025-07-11 09:17:12', '2025-07-11 09:17:12'),
('5', '4', '3', '5', '59.00', '295.00', '75.00', '2025-07-11 09:17:12', '2025-07-11 09:17:12');


CREATE TABLE `return_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `customer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_records_user_id_foreign` (`user_id`),
  KEY `return_records_created_at_index` (`created_at`),
  KEY `return_records_store_id_index` (`store_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `return_records` VALUES
('4', '1', '1', NULL, '440.00', '95.00', NULL, NULL, '2025-07-11 09:17:12', '2025-07-11 09:17:12');


CREATE TABLE `role_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_permission_role_id_foreign` (`role_id`),
  KEY `role_permission_permission_id_foreign` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_code_unique` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` VALUES
('1', '超级管理员', 'super_admin', '超级管理员', '系统超级管理员，拥有所有权限', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('2', '管理员', 'admin', '管理员', '系统管理员，拥有大部分权限', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('3', '库存管理员', 'inventory_manager', '库存管理员', '负责库存管理', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('4', '销售员', 'sales', '销售员', '负责销售操作', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('5', '普通用户', 'user', '普通用户', '普通用户，只有基本权限', '2025-07-08 15:22:34', '2025-07-08 15:22:34');


CREATE TABLE `sale_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `product_variant_id` bigint(20) unsigned DEFAULT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品SKU',
  `product_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL COMMENT '单价',
  `cost` decimal(10,2) DEFAULT NULL COMMENT '单位成本',
  `cost_price` decimal(8,2) DEFAULT NULL,
  `total` decimal(12,2) NOT NULL COMMENT '总金额',
  `profit` decimal(12,2) DEFAULT NULL COMMENT '利润',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_details_product_id_foreign` (`product_id`),
  KEY `sale_details_product_variant_id_index` (`product_variant_id`),
  KEY `sale_details_sku_index` (`sku`),
  KEY `sale_details_sale_id_product_variant_id_index` (`sale_id`,`product_variant_id`),
  KEY `sale_details_sale_id_index` (`sale_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_details` VALUES
('16', '10', '2', NULL, NULL, NULL, '9', '29.00', '4.00', '4.00', '261.00', '225.00', NULL, '2025-07-10 18:10:27', '2025-07-10 18:10:27'),
('17', '11', '1', NULL, NULL, NULL, '10', '39.00', '0.00', '0.00', '390.00', '390.00', NULL, '2025-07-10 18:11:04', '2025-07-10 18:11:04'),
('18', '11', '9', NULL, NULL, NULL, '10', '79.00', '0.00', '0.00', '790.00', '790.00', NULL, '2025-07-10 18:11:04', '2025-07-10 18:11:04'),
('19', '12', '1', NULL, NULL, NULL, '10', '39.00', '0.00', '0.00', '390.00', '390.00', NULL, '2025-07-11 06:02:05', '2025-07-11 06:02:05'),
('20', '12', '9', NULL, NULL, NULL, '10', '79.00', '0.00', '0.00', '790.00', '790.00', NULL, '2025-07-11 06:02:05', '2025-07-11 06:02:05'),
('21', '13', '1', NULL, NULL, NULL, '10', '39.00', '0.00', '0.00', '390.00', '390.00', NULL, '2025-07-11 12:13:33', '2025-07-11 12:13:33'),
('22', '13', '9', NULL, NULL, NULL, '10', '79.00', '0.00', '0.00', '790.00', '790.00', NULL, '2025-07-11 12:13:33', '2025-07-11 12:13:33');


CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_profit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `profit_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `store_id` bigint(20) unsigned NOT NULL,
  `sale_type` enum('standard','blind_bag','mixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'standard',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_order_no_unique` (`order_no`),
  KEY `sales_user_id_foreign` (`user_id`),
  KEY `sales_store_id_sale_type_index` (`store_id`),
  KEY `sales_created_at_sale_type_index` (`created_at`),
  KEY `sales_created_at_index` (`created_at`),
  KEY `sales_store_id_index` (`store_id`),
  KEY `sales_created_at_total_amount_index` (`created_at`,`total_amount`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sales` VALUES
('11', NULL, NULL, NULL, NULL, NULL, '1180.00', '489.00', '691.00', '58.56', '1', '2025-07-10 18:11:04', '2025-07-10 18:11:04', '1', 'blind_bag'),
('10', NULL, NULL, NULL, NULL, NULL, '261.00', '4.00', '257.00', '98.47', '1', '2025-07-10 18:10:27', '2025-07-10 18:10:27', '1', 'standard'),
('12', NULL, NULL, NULL, NULL, NULL, '1180.00', '405.00', '775.00', '65.68', '1', '2025-07-11 06:02:05', '2025-07-11 06:02:05', '1', 'blind_bag'),
('13', NULL, NULL, NULL, NULL, NULL, '1180.00', '440.00', '740.00', '62.71', '1', '2025-07-11 12:13:33', '2025-07-11 12:13:33', '1', 'blind_bag');


CREATE TABLE `stock_in_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_in_record_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL COMMENT '入库单价',
  `total_amount` decimal(10,2) NOT NULL COMMENT '入库总金额',
  `unit_cost` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_in_details_stock_in_record_id_foreign` (`stock_in_record_id`),
  KEY `stock_in_details_product_id_foreign` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_in_details` VALUES
('4', '7', '2', '2000', '4.00', '8000.00', '4.00', '8000.00', '2025-07-10 17:01:31', '2025-07-10 17:01:31'),
('5', '7', '3', '1000', '15.00', '15000.00', '15.00', '15000.00', '2025-07-10 17:01:31', '2025-07-10 17:01:31'),
('6', '7', '4', '500', '25.00', '12500.00', '25.00', '12500.00', '2025-07-10 17:01:31', '2025-07-10 17:01:31'),
('7', '7', '5', '50', '70.00', '3500.00', '70.00', '3500.00', '2025-07-10 17:01:31', '2025-07-10 17:01:31');


CREATE TABLE `stock_in_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `supplier` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_in_records_user_id_foreign` (`user_id`),
  KEY `stock_in_records_created_at_index` (`created_at`),
  KEY `stock_in_records_store_id_index` (`store_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_in_records` VALUES
('7', '1', '', '1', '39000.00', '39000.00', NULL, '2025-07-10 17:01:31', '2025-07-10 17:01:31');


CREATE TABLE `stock_out_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_out_record_id` bigint(20) unsigned NOT NULL,
  `price_series_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_out_details_stock_out_record_id_foreign` (`stock_out_record_id`),
  KEY `stock_out_details_price_series_id_foreign` (`price_series_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `stock_out_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `customer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_out_records_user_id_foreign` (`user_id`),
  KEY `stock_out_records_created_at_index` (`created_at`),
  KEY `stock_out_records_store_id_index` (`store_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `store_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_store_product` (`store_id`,`product_id`),
  KEY `store_products_store_id_is_active_index` (`store_id`,`is_active`),
  KEY `store_products_product_id_is_active_index` (`product_id`,`is_active`),
  KEY `store_products_sort_order_index` (`sort_order`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `store_products` VALUES
('19', '1', '3', '1', '0', NULL, '2025-07-10 16:55:49', '2025-07-10 16:55:49'),
('16', '1', '4', '1', '0', NULL, '2025-07-10 16:52:18', '2025-07-10 16:52:18'),
('17', '1', '9', '1', '0', NULL, '2025-07-10 16:52:18', '2025-07-10 16:52:18'),
('18', '1', '2', '1', '0', NULL, '2025-07-10 16:55:49', '2025-07-10 16:55:49'),
('20', '1', '5', '1', '0', NULL, '2025-07-10 16:55:49', '2025-07-10 16:55:49'),
('21', '1', '1', '1', '0', NULL, '2025-07-10 16:55:49', '2025-07-10 16:55:49');


CREATE TABLE `store_transfers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '调拨单号',
  `source_store_id` bigint(20) unsigned NOT NULL COMMENT '源仓库ID',
  `target_store_id` bigint(20) unsigned NOT NULL COMMENT '目标仓库ID',
  `product_id` bigint(20) unsigned NOT NULL COMMENT '商品ID',
  `quantity` int(11) NOT NULL COMMENT '调拨数量',
  `unit_cost` decimal(10,2) NOT NULL COMMENT '单位成本',
  `total_cost` decimal(10,2) NOT NULL COMMENT '总成本',
  `status` enum('pending','approved','rejected','in_transit','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT '调拨状态',
  `reason` text COLLATE utf8mb4_unicode_ci COMMENT '调拨原因',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `requested_by` bigint(20) unsigned NOT NULL COMMENT '申请人ID',
  `approved_by` bigint(20) unsigned DEFAULT NULL COMMENT '审批人ID',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT '审批时间',
  `completed_at` timestamp NULL DEFAULT NULL COMMENT '完成时间',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `store_transfers_transfer_no_unique` (`transfer_no`),
  KEY `store_transfers_product_id_foreign` (`product_id`),
  KEY `store_transfers_requested_by_foreign` (`requested_by`),
  KEY `store_transfers_approved_by_foreign` (`approved_by`),
  KEY `store_transfers_source_store_id_status_index` (`source_store_id`,`status`),
  KEY `store_transfers_target_store_id_status_index` (`target_store_id`,`status`),
  KEY `store_transfers_created_at_index` (`created_at`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `store_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `store_user_user_store_index` (`user_id`,`store_id`),
  KEY `store_user_user_id_index` (`user_id`),
  KEY `store_user_store_id_index` (`store_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `store_user` VALUES
('1', '1', '1', NULL, NULL),
('2', '2', '1', NULL, NULL);


CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stores_code_unique` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stores` VALUES
('1', 'Live1', 'L10001', NULL, NULL, NULL, NULL, '1', '2025-07-09 14:06:06', '2025-07-09 14:06:06', NULL),
('2', 'Live2', 'L10002', NULL, NULL, NULL, NULL, '1', '2025-07-12 16:30:15', '2025-07-12 16:30:15', NULL);


CREATE TABLE `system_configs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_configs_key_unique` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_configs` VALUES
('1', 'inventory_warning_threshold', '10', '库存预警阈值', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('2', 'system_name', '越南盲袋库存管理系统', '系统名称', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('3', 'system_language', 'zh_CN', '系统默认语言', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('4', 'currency', 'CNY', '系统货币', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('5', 'date_format', 'Y-m-d', '日期格式', '2025-07-08 15:22:34', '2025-07-08 15:22:34'),
('6', 'time_format', 'H:i:s', '时间格式', '2025-07-08 15:22:34', '2025-07-08 15:22:34');


CREATE TABLE `unified_inventories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `inventory_type` enum('product_variant','price_series') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '库存类型',
  `reference_id` bigint(20) NOT NULL COMMENT '关联ID (product_variant_id 或 price_series.id)',
  `reference_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '关联编码 (variant_sku 或 series_code)',
  `quantity` int(11) NOT NULL DEFAULT '0' COMMENT '库存数量',
  `reserved_quantity` int(11) NOT NULL DEFAULT '0' COMMENT '预留数量',
  `min_quantity` int(11) NOT NULL DEFAULT '10' COMMENT '最小库存',
  `max_quantity` int(11) NOT NULL DEFAULT '1000' COMMENT '最大库存',
  `last_check_at` timestamp NULL DEFAULT NULL COMMENT '最后盘点时间',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_store_type_ref` (`store_id`,`inventory_type`,`reference_id`),
  KEY `unified_inventories_inventory_type_reference_id_index` (`inventory_type`,`reference_id`),
  KEY `unified_inventories_store_id_inventory_type_index` (`store_id`,`inventory_type`),
  KEY `unified_inventories_reference_code_index` (`reference_code`),
  KEY `unified_inventories_store_id_quantity_index` (`store_id`,`quantity`),
  KEY `unified_inventories_product_id_foreign` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `unified_inventories` VALUES
('1', '1', NULL, 'product_variant', '2', 'P29', '154', '0', '10', '500', NULL, NULL, '2025-07-09 15:51:36', '2025-07-09 16:01:11'),
('2', '1', NULL, 'product_variant', '3', 'P59', '185', '0', '10', '500', NULL, NULL, '2025-07-09 15:51:36', '2025-07-09 16:01:11'),
('3', '1', NULL, 'product_variant', '4', 'P89', '103', '0', '10', '500', NULL, NULL, '2025-07-09 15:51:36', '2025-07-09 16:01:11'),
('4', '1', NULL, 'product_variant', '5', 'P159', '173', '0', '10', '500', NULL, NULL, '2025-07-09 15:51:36', '2025-07-09 16:01:11');


CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `real_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `role_id` bigint(20) unsigned NOT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  KEY `users_email_index` (`email`),
  KEY `users_username_index` (`username`),
  KEY `users_is_active_index` (`is_active`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES
('1', 'jakonwang', '$2y$12$lI.Zg/R5zvCdDoZ9kYjC2eGPL9YVyfTvXKirUytYErlEco4RO4Xbq', '管理员', 'jakonwang@163.com', '13800138000', '1', '1', NULL, NULL, NULL, '2025-07-08 15:22:35', '2025-07-12 16:30:48');
